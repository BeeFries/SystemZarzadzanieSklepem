import express from "express";
import mongoose from "mongoose";
import ShopShelf from "./models/ShopShelf.js";
import User from "./models/User.js";
import Product from "./models/Product.js";
import Shop from "./models/Shop.js";

import {
  ShelfBeforeDynamic,
  ShelfAfterDynamic,
} from "./dynamic-pages/Polka.js";

import {
  ProductBeforeDynamic,
  ProductAfterDynamic,
} from "./dynamic-pages/Product.js";

import {
  ShopBeforeDynamic,
  ShopAfterDynamic,
} from "./dynamic-pages/Sklep.js";

import {
  ArchiveBeforeDynamic,
  ArchiveAfterDynamic,
} from "./dynamic-pages/Archiwum.js";

const PORT = 5000;
const DB_NAME = "MyDB";
const DB_URL = "mongodb://127.0.0.1:27017/" + DB_NAME;
let userId = null;

const app = express();

app.use(express.text());

app.get("/addShopShelf", (req, res) => {
  const {
    //Достаем с body с этой
    category,
    capacity,
  } = req.query;

  const shopShelf = new ShopShelf({
    //обьект usera для БД
    category,
    capacity,
    exist: true
  });

  shopShelf
    .save() //сохранил в БД
    .then(() => res.redirect("/Polka")) //ели успешно сохранилось - создаю ответ с этой моделькой
    .catch((error) => {
      console.log(error);
      res.redirect("/Polka");
    });
});
////
app.get("/removeShopShelf", (req, res) => {
  const {
    //Достаем с body с этой
    _id,
  } = req.query;

  ShopShelf.findByIdAndUpdate(_id, {"exist":false })
    .then((x) => res.redirect("/Polka"))
    .catch((x) => res.redirect("/Polka"));
});

app.get("/addProduct", (req, res) => {
  const {
    //Достаем с body с этой
    name,
    category,
    description,
    date,
    price,
  } = req.query;

  const product = new Product({
    //обьект usera для БД
    name,
    category,
    description,
    date,
    price,
    exist: true
  });

  product
    .save() //сохранил в БД
    .then(() => res.redirect("/Products")) //ели успешно сохранилось - создаю ответ с этой моделькой
    .catch((error) => {
      console.log(error);
      res.redirect("/Products");
    });
});

app.get("/removeProduct", (req, res) => {
  const {
    //Достаем с body с этой
    _id,
  } = req.query;

  Product.findByIdAndUpdate(_id, {"exist":false })
    .then((x) => res.redirect("/Products"))
    .catch((x) => res.redirect("/Products"));
});

app.get("/addShop", (req, res) => {
  const {
    //Достаем с body с этой
    name,
    phoneNumber,
    email,
    address,
  } = req.query;

  const shop = new Shop({
    //обьект usera для БД
    name,
    phoneNumber,
    email,
    address,
    exist: true
  });

  shop
    .save() //сохранил в БД
    .then(() => res.redirect("/Shop")) //ели успешно сохранилось - создаю ответ с этой моделькой
    .catch((error) => {
      console.log(error);
      res.redirect("/Shop");
    });
});

app.get("/removeShop", (req, res) => {
  const {
    //Достаем с body с этой
    _id,
  } = req.query;

  Shop.findByIdAndUpdate(_id, {"exist":false })
    .then((x) => res.redirect("/Shop"))
    .catch((x) => res.redirect("/Shop"));
});

app.get("/login", (req, res) => {
  const {
    //Достаем с body с этой
    email,
    password,
  } = req.query;

  User.findOne({ email: email, password: password })
    .then((x) => {
      if(!x){
        res.redirect("/");
        return;
      }

      userId = x;
      res.redirect("/mainPage");
    })
    .catch((x) => res.redirect("/"));
});

app.get("/register", (req, res) => {
  const {
    //Достаем с body с этой
    name,
    surname,
    email,
    password,
    phoneNumber,
    city,
    residenceAdress,
    postalCode,
  } = req.query;

  const user = new User({
    //обьект usera для БД
    name,
    surname,
    email,
    password,
    phoneNumber,
    city,
    residenceAdress,
    postalCode,
  });

  user
    .save() //сохранил в БД
    .then((x) =>{
      userId = x;
      res.redirect("/mainPage");
    }) //ели успешно сохранилось - создаю ответ с этой моделькой
    .catch((error) => {
      console.log(error);
      res.redirect("/auth/register");
    });
});

app.get("/", (req, res) => {
  res.sendFile("./pages/Logowanie.html", { root: "./" });
});

app.get("/auth/register", (req, res) => {
  res.sendFile("./pages/Rejestracja.html", { root: "./" });
});

app.get("/archive", async(req, res) => {

  if(!userId){
    res.redirect("/");
    return;
  }

  const items = [];


  const shopShelfs = await ShopShelf.find();
  const shops = await Shop.find();
  const products = await Product.find();
  // shopShelfs[0].updatedAt.getDate();

  fulFillItems("Polka", shopShelfs, items);
  fulFillItems("Sklep", shops, items);
  fulFillItems("Product", products, items);


  let html = ArchiveBeforeDynamic;//c++ int/bool/.. tipo variable

  for (const item of items) {
    html +=
      " <tr>" +
      `<th scope="row">${item.id}</th>` +
      `<td>${item.name}</td>` +
      `<td>${item.updatedAt}</td>` +
      "    </tr>";
  }

  html += ArchiveAfterDynamic;

  res.status(200).send(html);

  
});
app.get("/mainPage", (req, res) => {
  if(!userId){
    res.redirect("/");
    return;
  }
  res.sendFile("./pages/StronaGlowna.html", { root: "./" });
});
///////////
app.get("/Shop", async (req, res) => {
  if(!userId){
    res.redirect("/");
    return;
  }
  const shops = await Shop.find({exist: true});

  console.log(shops);

  let html = ShopBeforeDynamic;

  for(const shop of shops){
    html += 
    "    <tr>" + 
`      <th scope="col">${shop._id}</th>` + 
`      <th scope="col">${shop.name}</th>` + 
`      <th scope="col">${shop.phoneNumber}</th>` + 
`      <th scope="col">${shop.email}</th>` + 
`      <th scope="col">${shop.address}</th>` + 

'<td> ' +
'<form action="http://localhost:5000/RemoveShop">' +
  `<input style = "visibility: hidden;" type="id" name="_id" value="${shop._id}"/>` +
  '<button type="submit" class="btn btn-danger" data-bs-target="#exampleModal">Usun</button>' +
'</form>'+
'</td>' +
"    </tr>";
  }
  html += ShopAfterDynamic;

  res.status(200).send(html);
  });

app.get("/Polka", async (req, res) => {
  if(!userId){
    res.redirect("/");
    return;
  }
  const shopShelfs = await ShopShelf.find({exist: true});

  console.log(shopShelfs);

  let html = ShelfBeforeDynamic;//c++ int/bool/.. tipo variable

  for (const shopShelf of shopShelfs) {
    html +=
      " <tr>" +
      `<th scope="row">${shopShelf._id}</th>` +
      `<td>${shopShelf.category}</td>` +
      `<td>${shopShelf.capacity}</td>` +
      "" +

      '<td> ' +
      '<form action="http://localhost:5000/RemoveShopShelf">' +
        `<input style = "visibility: hidden;" type="id" name="_id" value="${shopShelf._id}"/>` +
        '<button type="submit" class="btn btn-danger" data-bs-target="#exampleModal">Usun</button>' +
      '</form>'+
    '</td>' +
      "    </tr>";
  }

  html += ShelfAfterDynamic;

  res.status(200).send(html);
});

app.get("/Products", async(req, res) => {
  if(!userId){
    res.redirect("/");
    return;
  }
  const products = await Product.find({exist: true});

  console.log(products);

  let html = ProductBeforeDynamic;

  for(const product of products)
  {
    html += 
    '    <tr>' + 
    `      <th scope="row">${product._id}</th>` + 
    `      <td>${product.name}</td>` + 
    `      <td>${product.category}</td>` + 
    `      <td>${product.description}</td>` + 
    `      <td>${product.date}</td>` + 
    `      <td>${product.price}</td>` + 
    '<td> ' +
      '<form action="http://localhost:5000/RemoveProduct">' +
        `<input style = "visibility: hidden;" type="id" name="_id" value="${product._id}"/>` +
        '<button type="submit" class="btn btn-danger" data-bs-target="#exampleModal">Usun</button>' +
      '</form>'+
    '</td>' +
    '    </tr>';
  }

  html += ProductAfterDynamic;

  res.status(200).send(html);
});

const startApp = () => {
  try {
    mongoose.set("strictQuery", false);
    mongoose.connect(DB_URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    app.listen(PORT, () => console.log("server started " + PORT));
  } catch (e) {
    console.log(e);
  }
};

function fulFillItems(name, array, items){
  for (const iterator of array) {
    items.push(
      {
        id: iterator._id, 
        name: name,
        updatedAt: iterator.updatedAt.toLocaleString()
      }
    )
  }
}

startApp();
