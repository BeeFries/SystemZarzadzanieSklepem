import mongoose from "mongoose";

const shopShelfSchema = new mongoose.Schema(
  {
    category: { type: String, required: true },
    capacity: { type: Number, required: true },
    exist:{ type: Boolean, required: true}
  },
  { timestamps: true } //добавляет переменные createdAt, updatedAt
);

export default mongoose.model("ShopShelf", shopShelfSchema);
