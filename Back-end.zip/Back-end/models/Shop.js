import mongoose from "mongoose";

const shopSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    phoneNumber: { type: Number, required: true },
    email: { type: String, required: true, unique: true },
    address: { type: String, required: true },
    exist:{ type: Boolean, required: true}
  },
  { timestamps: true } //добавляет переменные createdAt, updatedAt
);

export default mongoose.model("Shop", shopSchema);