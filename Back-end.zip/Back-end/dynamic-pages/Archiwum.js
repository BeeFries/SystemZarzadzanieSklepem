export const ArchiveBeforeDynamic= '' + 
'<!DOCTYPE html>' + 
'' + 
'<html lang="en" xmlns="http://www.w3.org/1999/xhtml">' + 
'<head>' + 
'    <meta charset="utf-8" />' + 
'    <title></title>' + 
'    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">' + 
'    <script src="https://kit.fontawesome.com/199b623830.js" crossorigin="anonymous"></script>' + 
'</head>' + 
'' + 
'<body>' + 
'<nav class="navbar navbar-expand-lg bg-light">' + 
'  <div class="container-fluid">' + 
'    <a class="navbar-brand" href="Strona glowna.html"><i class="fa-solid fa-car"></i> Nazwa projektu</a>' + 
'    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">' + 
'      <span class="navbar-toggler-icon"></span>' + 
'    </button>' + 
'    <div class="collapse navbar-collapse" id="navbarSupportedContent">' + 
'      <ul class="navbar-nav me-auto mb-2 mb-lg-0">' + 
'        <li class="nav-item">' + 
'          <a class="nav-link active" aria-current="page" href="http://localhost:5000/mainPage">Strona glowna</a>' + 
'        </li>' + 
'' + 
'        <li class="nav-item">' + 
'          <a class="nav-link active" aria-current="page" href="http://localhost:5000/archive">Archiwum</a>' + 
'        </li>' + 
'' + 
'        <li class="nav-item">' + 
'          <a class="nav-link active" aria-current="page" href="#">Pomocnik pracownika</a>' + 
'        </li>' + 
'' + 
'        <li class="nav-item">' + 
'          <a class="nav-link active" aria-current="page" href="#">Zebrania</a>' + 
'        </li>' + 
'' + 
'        <li class="nav-item">' + 
'          <a class="nav-link active" aria-current="page" href="#">Ustawienia</a>' + 
'        </li>' + 
'' + 
'        <li class="nav-item">' + 
'          <a class="nav-link active" aria-current="page" href="#">Administrator</a>' + 
'        </li>' + 
'' + 
'      </ul>' + 
'' + 
'      <form class="d-flex" role="search">' + 
'        <input class="form-control me-2" type="search" placeholder="Wpisz tu tekst..." aria-label="Search">' + 
'        <button class="btn btn-outline-success" type="submit">Szukaj</button>' + 
'      </form>' + 
'    </div>' + 
'  </div>' + 
'</nav>' + 
'' + 
'<h3 style="margin: 20px 40px;">Archiwum</h1> ' + 
'' + 
'' + 
'<table class="table">' + 
'  <thead>' + 
'    <tr>' + 
'      <th scope="col">Id</th>' + 
'      <th scope="col">Skad zarchiwizowane</th>' + 
'      <th scope="col">Dane archiwne</th>' + 
'    </tr>' + 
'  </thead>' + 
'  <tbody>';

export const ArchiveAfterDynamic = '' + 
'' + 
'  </tbody>' + 
'</table>' + 
'' + 
'' + 
'</body>' + 
'</html>' + 
'';
