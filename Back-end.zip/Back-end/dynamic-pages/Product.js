export const ProductBeforeDynamic = '' + 
'<!DOCTYPE html>' + 
'' + 
'<html lang="en" xmlns="http://www.w3.org/1999/xhtml">' + 
'<head>' + 
'    <meta charset="utf-8" />' + 
'    <title></title>' + 
'    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">' + 
'    <script src="https://kit.fontawesome.com/199b623830.js" crossorigin="anonymous"></script>' + 
'</head>' + 
'' + 
'<body>' + 
'<nav class="navbar navbar-expand-lg bg-light">' + 
'  <div class="container-fluid">' + 
'    <a class="navbar-brand" href="Strona glowna.html"><i class="fa-solid fa-car"></i> Nazwa projektu</a>' + 
'    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">' + 
'      <span class="navbar-toggler-icon"></span>' + 
'    </button>' + 
'    <div class="collapse navbar-collapse" id="navbarSupportedContent">' + 
'      <ul class="navbar-nav me-auto mb-2 mb-lg-0">' + 
'        <li class="nav-item">' + 
'          <a class="nav-link active" aria-current="page" href="http://localhost:5000/mainPage">Strona glowna</a>' + 
'        </li>' + 
'' + 
'        <li class="nav-item">' + 
'          <a class="nav-link active" aria-current="page" href="http://localhost:5000/archive">Archiwum</a>' + 
'        </li>' + 
'' + 
'        <li class="nav-item">' + 
'          <a class="nav-link active" aria-current="page" href="#">Pomocnik pracownika</a>' + 
'        </li>' + 
'' + 
'        <li class="nav-item">' + 
'          <a class="nav-link active" aria-current="page" href="#">Zebrania</a>' + 
'        </li>' + 
'' + 
'        <li class="nav-item">' + 
'          <a class="nav-link active" aria-current="page" href="#">Ustawienia</a>' + 
'        </li>' + 
'' + 
'        <li class="nav-item">' + 
'          <a class="nav-link active" aria-current="page" href="#">Administrator</a>' + 
'        </li>' + 
'' + 
'      </ul>' + 
'' + 
'      <form class="d-flex" role="search">' + 
'        <input class="form-control me-2" type="search" placeholder="Wpisz tu tekst..." aria-label="Search">' + 
'        <button class="btn btn-outline-success" type="submit">Szukaj</button>' + 
'      </form>' + 
'    </div>' + 
'  </div>' + 
'</nav>' + 
'' + 
'<h3 style="margin: 20px 40px;">Zarzadzanie magazynem/sklepem</h1> ' + 
'' + 
'<form style = "display: flex; margin-right:500px;" action = "http://localhost:5000/addProduct">' + 
'    <input name = "name" type="nazwa" class="form-control" id="exampleInputNazw" placeholder="Nazwa">' + 
'    <input name = "category" type="kategoria" class="form-control" id="exampleInputKat" placeholder="Kategoria">' + 
'    <input name = "description" type="opis" class="form-control" id="exampleInputOpis" placeholder="Opis">' + 
'    <input name = "date" type="data" class="form-control" id="exampleInputData" placeholder="Data przyjecia">' + 
'    <input name = "price" type="cena" class="form-control" id="exampleInputCena" placeholder="Cena (zl)">' + 
'  <button type="submit" class="btn btn-success">Dodaj</button>' + 
'</form>' + 
'' + 
'<table class="table">' + 
'  <thead>' + 
'    <tr>' + 
'      <th scope="col">Id produktu</th>' + 
'      <th scope="col">Nazwa</th>' + 
'      <th scope="col">Kategoria</th>' + 
'      <th scope="col">Opis</th>' + 
'      <th scope="col">Data przyjecia</th>' + 
'      <th scope="col">Cena (zl)</th>' + 
'    </tr>' + 
'  </thead>' + 
'  <tbody>';
export const ProductAfterDynamic = '' + 
'' + 
'  </tbody>' + 
'</table>' + 
'' + 
'' + 
'</body>' + 
'</html>' + 
'';